

package view;

import viewapp.inicio;


/**
 *
 * @author USUARIO
 */
public class Parcial2empresa {

    public static void main(String[] args) {
        inicio v = new inicio();
            v.setVisible(true);
    }
}
